#!/usr/bin/env bash
# Пересборка APK для обновлений (Ubuntu / WSL).
# 1) Один раз: sudo apt install -y android-sdk-platform-23 aapt apksigner zipalign dalvik-exchange openjdk-17-jdk-headless
# 2) Положи новую версию игры в assets/index.html
# 3) В AndroidManifest.xml увеличь versionCode (1 -> 2 -> 3...) и versionName
# 4) Запусти: ./build-apk.sh ../keystore/drift-release.jks ПАРОЛЬ
set -e
KS="$1"; PW="$2"; AJ=/usr/lib/android-sdk/platforms/android-23/android.jar
rm -rf out && mkdir -p out/obj
javac -nowarn -source 8 -target 8 -bootclasspath $AJ -classpath $AJ -d out/obj src/ru/stuzhin/tower/MainActivity.java
dalvik-exchange --dex --output=out/classes.dex out/obj
aapt package -f -M AndroidManifest.xml -S res -A assets -I $AJ -F out/unsigned.apk
(cd out && aapt add unsigned.apk classes.dex >/dev/null)
zipalign -f -p 4 out/unsigned.apk out/aligned.apk
VER=$(grep -o 'versionName="[^"]*"' AndroidManifest.xml | cut -d'"' -f2)
apksigner sign --ks "$KS" --ks-key-alias drift --ks-pass pass:"$PW" --key-pass pass:"$PW" --out "tower-$VER.apk" out/aligned.apk
rm -f "tower-$VER.apk.idsig"; apksigner verify "tower-$VER.apk" && echo "Готово: tower-$VER.apk"
